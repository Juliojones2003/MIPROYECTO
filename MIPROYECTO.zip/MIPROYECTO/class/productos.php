<?php
/* @autor Miguel Angel Rangel Villarreal */

class Producto {
    private $id;
    private $nombre;
    private $imagen;
    private $descripcion;
    private $precio;
    private $categoria_id;
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    // Setters
    public function setId($id) { $this->id = $id; }
    public function setNombre($nombre) { $this->nombre = trim($nombre); }
    public function setImagen($imagen) { $this->imagen = trim($imagen); }
    public function setDescripcion($descripcion) { $this->descripcion = trim($descripcion); }
    public function setPrecio($precio) { $this->precio = $precio; }
    public function setCategoriaId($categoria_id) { $this->categoria_id = $categoria_id; }

    public function guardar() {
        $datos = [
            'nombre' => $this->nombre,
            'imagen' => $this->imagen,
            'descripcion' => $this->descripcion,
            'precio' => $this->precio,
            'categoria_id' => $this->categoria_id
        ];
        
        if (empty($this->id)) {
            $this->db->insert('productos', $datos);
        } else {
            $condicion = ['key' => 'id', 'value' => $this->id];
            $this->db->update('productos', $datos, $condicion);
        }
        return true;
    }
    
    public static function listar() {
        $db = Database::getInstance();
        $query = "SELECT p.*, c.nombre AS categoria_nombre FROM productos p JOIN categorias c ON p.categoria_id = c.id ORDER BY p.nombre ASC";
        return $db->select($query);
    }
    
    public static function obtenerPorId($id) {
        $db = Database::getInstance();
        $query = "SELECT * FROM productos WHERE id = :id";
        $resultado = $db->select($query, [':id' => $id]);
        return $resultado ? $resultado[0] : null;
    }

    public static function eliminar($id) {
        $db = Database::getInstance();
        $condicion = ['key' => 'id', 'value' => $id];
        return $db->delete('productos', $condicion);
    }
}