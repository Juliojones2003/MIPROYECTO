<?php
/* @autor Miguel Angel Rangel Villarreal */
require_once '../class/autoload.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: lista_productos.php');
    exit();
}

$id = $_GET['id'];
$producto = Producto::obtenerPorId($id);
$categorias = Categoria::listar(); // Necesitamos la lista de categorías para el <select>

if (!$producto) {
    header('Location: lista_productos.php');
    exit();
}

// Incluimos la vista del formulario para que muestre los datos
include 'views/productos.html';