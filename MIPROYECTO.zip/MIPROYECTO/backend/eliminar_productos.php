<?php
/* @autor Miguel Angel Rangel Villarreal */
require_once '../class/autoload.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Opcional: podrías querer eliminar también el archivo de imagen del servidor aquí
    Producto::eliminar($_GET['id']);
}

header('Location: lista_productos.php');
exit();