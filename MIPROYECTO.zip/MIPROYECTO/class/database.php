<?php
/* @autor Miguel Angel Rangel Villarreal */

class Database {
    private static $instancia = null;
    private $pdo;

    private function __construct() {
        $host = 'localhost';
        $dbname = 'miproyecto';
        $user = 'root';
        $pass = '';

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión a la base de datos: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instancia === null) {
            self::$instancia = new Database();
        }
        return self::$instancia;
    }

    public function select($query, $params = []) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function insert($tabla, $datos) {
        $columnas = implode(', ', array_keys($datos));
        $placeholders = ':' . implode(', :', array_keys($datos));
        $query = "INSERT INTO $tabla ($columnas) VALUES ($placeholders)";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($datos);
        return $this->pdo->lastInsertId();
    }
    
    public function update($tabla, $datos, $condicion) {
        $setStr = '';
        foreach ($datos as $key => $value) {
            $setStr .= "$key = :$key, ";
        }
        $setStr = rtrim($setStr, ', ');
        $query = "UPDATE $tabla SET $setStr WHERE {$condicion['key']} = :condicion_valor";
        $stmt = $this->pdo->prepare($query);
        $datos['condicion_valor'] = $condicion['value'];
        return $stmt->execute($datos);
    }
    
    public function delete($tabla, $condicion) {
        $query = "DELETE FROM $tabla WHERE {$condicion['key']} = :condicion_valor";
        $stmt = $this->pdo->prepare($query);
        return $stmt->execute(['condicion_valor' => $condicion['value']]);
    }
}