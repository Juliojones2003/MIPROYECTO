<?php
/* @autor Miguel Angel Rangel Villarreal */
require_once '../class/autoload.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $producto = new Producto();

    // Si se envía un ID, es una actualización. Lo asignamos.
    if (!empty($_POST['id'])) {
        $producto->setId($_POST['id']);
    }

    // Asignamos los datos del formulario
    $producto->setNombre($_POST['nombre_producto']);
    $producto->setDescripcion($_POST['descripcion']);
    $producto->setPrecio($_POST['precio']);
    $producto->setCategoriaId($_POST['id_categoria']);
    
    // Manejo de la imagen
    $nombre_imagen = $_POST['imagen_actual']; // Mantenemos la imagen actual por defecto
    if (isset($_FILES['imagen_producto']) && $_FILES['imagen_producto']['error'] == 0) {
        $directorio_destino = '../assets/img/';
        // Usamos un nombre único para evitar sobreescribir archivos
        $nombre_imagen = uniqid() . '_' . basename($_FILES['imagen_producto']['name']);
        $ruta_destino = $directorio_destino . $nombre_imagen;
        move_uploaded_file($_FILES['imagen_producto']['tmp_name'], $ruta_destino);
    }
    $producto->setImagen($nombre_imagen);
    
    $producto->guardar();
    
    header('Location: lista_productos.php');
    exit();
}