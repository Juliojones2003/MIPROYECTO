<?php
/* @autor Miguel Angel Rangel Villarreal */
require_once '../class/autoload.php';

// Si no hay ID, redirige al listado
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: lista_categorias.php');
    exit();
}

$id = $_GET['id'];
$categoria = Categoria::obtenerPorId($id);

// Si la categoría no existe, redirige al listado
if (!$categoria) {
    header('Location: lista_categorias.php');
    exit();
}

// Incluye la vista del formulario, que se rellenará con los datos de $categoria
include 'views/categorias.html';