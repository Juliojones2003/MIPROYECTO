<?php
/* @autor Miguel Angel Rangel Villarreal */
require_once '../class/autoload.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    Categoria::eliminar($_GET['id']);
}

header('Location: lista_categorias.php');
exit();