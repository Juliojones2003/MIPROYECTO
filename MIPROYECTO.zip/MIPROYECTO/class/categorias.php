<?php
/* @autor Miguel Angel Rangel Villarreal */

class Categoria {
    private $id;
    private $nombre;
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    public function setId($id) { $this->id = $id; }
    public function setNombre($nombre) { $this->nombre = trim($nombre); }

    public function guardar() {
        $datos = ['nombre' => $this->nombre];
        
        if (empty($this->id)) {
            $this->db->insert('categorias', $datos);
        } else {
            $condicion = ['key' => 'id', 'value' => $this->id];
            $this->db->update('categorias', $datos, $condicion);
        }
        return true;
    }
    
    public static function listar() {
        $db = Database::getInstance();
        $query = "SELECT * FROM categorias ORDER BY nombre ASC";
        return $db->select($query);
    }
    
    public static function obtenerPorId($id) {
        $db = Database::getInstance();
        $query = "SELECT * FROM categorias WHERE id = :id";
        $resultado = $db->select($query, [':id' => $id]);
        return $resultado ? $resultado[0] : null;
    }

    public static function eliminar($id) {
        $db = Database::getInstance();
        $condicion = ['key' => 'id', 'value' => $id];
        return $db->delete('categorias', $condicion);
    }
}