// Usamos $(function() { ... }); como atajo para $(document).ready(function() { ... });
// Esto asegura que nuestro código se ejecute solo después de que toda la página se haya cargado.
$(function() {

    // --- VALIDACIÓN DEL FORMULARIO DE CATEGORÍAS ---
    $('#form-categoria').on('submit', function(event) {
        // Creamos un array para guardar los nombres de los campos inválidos.
        let camposInvalidos = [];

        // Buscamos el input de texto dentro de este formulario.
        const nombreCategoria = $('#nombre_categoria');

        // Usamos .trim() para quitar los espacios en blanco de los extremos.
        // Si después de quitar los espacios el valor es "", el campo es inválido.
        if (nombreCategoria.val().trim() === '') {
            camposInvalidos.push('Nombre de la Categoría');
        }

        // Si el array tiene al menos un elemento, significa que hay errores.
        if (camposInvalidos.length > 0) {
            // Prevenimos el envío del formulario.
            event.preventDefault();

            // Construimos el mensaje de alerta.
            // \n es un salto de línea.
            let mensaje = 'Los siguientes campos no pueden estar vacíos o contener solo espacios:\n\n' +
                          camposInvalidos.join('\n') +
                          '\n\n' +
                          'Tu Nombre y Apellido'; // Reemplaza esto con tu nombre real.

            // Mostramos la alerta.
            alert(mensaje);
        }
    });

    // --- VALIDACIÓN DEL FORMULARIO DE PRODUCTOS ---
    $('#form-producto').on('submit', function(event) {
        // El proceso es idéntico, pero revisando todos los campos del formulario de productos.
        let camposInvalidos = [];

        // Revisamos cada campo usando su id.
        if ($('#nombre_producto').val().trim() === '') {
            camposInvalidos.push('Nombre del Producto');
        }

        if ($('#descripcion').val().trim() === '') {
            camposInvalidos.push('Descripción');
        }

        if ($('#precio').val().trim() === '') {
            camposInvalidos.push('Precio');
        }

        // Para el 'select', verificamos que se haya elegido una opción válida.
        if ($('#categoria').val() === null || $('#categoria').val() === '') {
            camposInvalidos.push('Categoría');
        }
        
        // Si hay campos inválidos, mostramos la alerta.
        if (camposInvalidos.length > 0) {
            event.preventDefault();

            let mensaje = 'Los siguientes campos no pueden estar vacíos o contener solo espacios:\n\n' +
                          camposInvalidos.join('\n') +
                          '\n\n' +
                          'Tu Nombre y Apellido'; // Reemplaza esto con tu nombre real.

            alert(mensaje);
        }
    });

});