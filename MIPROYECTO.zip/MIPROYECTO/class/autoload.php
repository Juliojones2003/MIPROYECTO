<?php
/* @autor Miguel Angel Rangel Villarreal */

spl_autoload_register(function ($nombre_clase) {
    // Convierte el nombre de la clase (ej: "Categoria") a minúsculas ("categoria")
    // y busca un archivo que coincida (ej: "categoria.php")
    $archivo = __DIR__ . '/' . strtolower($nombre_clase) . '.php';
    
    if (file_exists($archivo)) {
        include $archivo;
    }
});