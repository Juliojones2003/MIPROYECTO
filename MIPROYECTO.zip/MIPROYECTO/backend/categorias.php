<?php
/* @autor Miguel Angel Rangel Villarreal */

// Usamos __DIR__ para crear una ruta absoluta y segura al autoloader.
// Esto le dice a PHP: "Desde esta carpeta, sube un nivel y entra en la carpeta 'class'".
require_once __DIR__ . '/../class/autoload.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Esta es la línea 9 que ahora funcionará
    $categoria = new Categoria();
    
    $categoria->setNombre($_POST['nombre_categoria']);

    if (!empty($_POST['id'])) {
        $categoria->setId($_POST['id']);
    }

    $categoria->guardar();
    
    header('Location: lista_categorias.php');
    exit();
}